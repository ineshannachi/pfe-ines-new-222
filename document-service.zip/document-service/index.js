// server.js
const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2/promise');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const proxy = require('express-http-proxy');


require('dotenv').config();

const uploadDir = path.join(__dirname, 'public', 'uploads');

// Vérifier si le dossier "uploads" existe, sinon le créer
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const app = express();

// Connexion à MySQL (via XAMPP)
async function waitForDB() {
  while (true) {
    try {
      const connection = await mysql.createConnection({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
      });
      console.log("✅ Connexion MySQL réussie !");
      connection.end();
      break;
    } catch (error) {
      console.log("❌ MySQL non disponible... Nouvelle tentative dans 3s");
      await new Promise((resolve) => setTimeout(resolve, 3000));
    }
  }
}

// Lancement après confirmation que MySQL est prêt
waitForDB().then(() => {
  const db = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
  });

  // Configuration de Multer pour enregistrer les fichiers dans /public/uploads
  const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
      // On préserve le nom d'origine avec un timestamp pour éviter les doublons
      cb(null, Date.now() + '-' + file.originalname);
    }
  });

  const upload = multer({ 
    storage: storage,
    limits: { fileSize: 10 * 1024 * 1024 }, // 10 Mo max
    fileFilter: (req, file, cb) => {
      const allowedMimeTypes = ['application/pdf', 'image/jpeg', 'image/png'];
      if (allowedMimeTypes.includes(file.mimetype)) {
        cb(null, true);
      } else {
        cb(new Error('Format de fichier non autorisé'));
      }
    }
  });

  // Configuration du moteur de vues EJS et des dossiers
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, 'views'));

  // Middleware
  app.use(bodyParser.urlencoded({ extended: false }));
  app.use(express.static(path.join(__dirname, 'public')));

  // Route d'accueil
  app.get('/', (req, res) => {
    res.render('home');
  });

  // Route : Afficher la liste des documents
  app.get('/documents', async (req, res) => {
    try {
      const [rows] = await db.query('SELECT * FROM documents');
      res.render('index', { documents: rows });
    } catch (error) {
      res.status(500).send(error.message);
    }
  });

  // Route : Afficher le formulaire d'ajout d'un document (saisie manuelle)
  app.get('/documents/add', (req, res) => {
    res.render('add');
  });

  // Route : Traiter l'ajout d'un document (saisie manuelle)
  app.post('/documents/add', async (req, res) => {
    const { titre, type_document, chemin } = req.body;
    try {
      await db.query(
        'INSERT INTO documents (titre, type_document, chemin) VALUES (?, ?, ?)',
        [titre, type_document, chemin]
      );
      res.redirect('/documents');
    } catch (error) {
      res.status(500).send(error.message);
    }
  });

  // Route : Afficher le formulaire d'upload d'un document (avec fichier)
  app.get('/upload', (req, res) => {
    res.render('upload');
  });

  // Route : Traiter l'upload d'un document
  app.post('/upload', upload.single('document'), async (req, res) => {
    // Vérification que tous les champs sont remplis
    const { titre, type_document, date_creation } = req.body;
    if (!titre || !type_document || !req.file) {
      return res.status(400).send("Tous les champs doivent être remplis.");
    }

    // Construction du chemin relatif pour sauvegarder dans la base
    const filePath = 'uploads/' + req.file.filename;

    try {
      await db.query(
        'INSERT INTO documents (titre, type_document, chemin, date_creation) VALUES (?, ?, ?, ?)',
        [titre, type_document, filePath, date_creation]
      );
      res.redirect('/documents');
    } catch (error) {
      res.status(500).send(error.message);
    }
  });

  // Route : Afficher le formulaire de modification d'un document
  app.get('/document/:id/edit', async (req, res) => {
    const { id } = req.params;
    try {
      const [rows] = await db.query('SELECT * FROM documents WHERE id_document = ?', [id]);
      if (rows.length > 0) {
        res.render('edit', { document: rows[0] });
      } else {
        res.status(404).send("Document non trouvé");
      }
    } catch (error) {
      res.status(500).send(error.message);
    }
  });

  // Route : Traiter la modification d'un document (remplacement éventuel du fichier)
  app.post('/document/:id/edit', upload.single('document'), async (req, res) => {
    const { id } = req.params;
    const { titre, type_document } = req.body;

    try {
      const [rows] = await db.query('SELECT * FROM documents WHERE id_document = ?', [id]);
      if (rows.length === 0) {
        return res.status(404).send("Document non trouvé");
      }

      let oldFilePath = rows[0].chemin;
      let newFilePath = oldFilePath;

      if (req.file) {
        newFilePath = 'uploads/' + req.file.filename;

        // Supprimer l'ancien fichier du disque
        if (fs.existsSync(path.join(__dirname, 'public', oldFilePath))) {
          fs.unlink(path.join(__dirname, 'public', oldFilePath), (err) => {
            if (err) console.error(err);
          });
        }
      }

      await db.query(
        'UPDATE documents SET titre = ?, type_document = ?, chemin = ? WHERE id_document = ?',
        [titre, type_document, newFilePath, id]
      );
      res.redirect('/documents');
    } catch (error) {
      res.status(500).send(error.message);
    }
  });

  // Route : Supprimer un document
  app.post('/document/:id/delete', async (req, res) => {
    const { id } = req.params;
    try {
      const [rows] = await db.query('SELECT chemin FROM documents WHERE id_document = ?', [id]);
      if (rows.length > 0) {
        const filePath = rows[0].chemin;
        // Supprimer le fichier du disque
        if (fs.existsSync(path.join(__dirname, 'public', filePath))) {
          fs.unlink(path.join(__dirname, 'public', filePath), (err) => {
            if (err) console.error(err);
          });
        }
      }
      await db.query('DELETE FROM documents WHERE id_document = ?', [id]);
      res.redirect('/documents');
    } catch (error) {
      res.status(500).send(error.message);
    }
  });

  // Exposer le dossier 'uploads' pour accéder aux fichiers
  app.use('/uploads', express.static(path.join(__dirname, 'public', 'uploads')));

  // Lancement du serveur
  const PORT = 3010;
  app.listen(PORT, () => {
    console.log(`Serveur démarré sur http://localhost:${PORT}`);
  });
});
