const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const mysql = require('mysql2/promise');
require('dotenv').config();

// Création de l'application Express et du serveur HTTP
const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// Configuration d'EJS comme moteur de vue
app.set('view engine', 'ejs');
app.set('views', './views');  // Dossier pour les fichiers EJS

// Middleware pour servir des fichiers statiques (CSS, JS, images)
app.use(express.static('public'));

// Attente de la disponibilité de MySQL
async function waitForDB() {
  while (true) {
    try {
      const connection = await mysql.createConnection({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
      });
      console.log("✅ Connexion MySQL réussie !");
      connection.end();
      break;
    } catch (error) {
      console.log("❌ MySQL non disponible... Nouvelle tentative dans 3s");
      await new Promise((resolve) => setTimeout(resolve, 3000));
    }
  }
}

// Lancement après confirmation que MySQL est prêt
waitForDB().then(() => {
  const pool = mysql.createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
  });

  let students = {};

  io.on('connection', (socket) => {
    console.log('Un étudiant s\'est connecté :', socket.id);

    socket.on('register', async (id_etudiant) => {
      students[id_etudiant] = socket.id;
      console.log(`👤 Étudiant ${id_etudiant} enregistré avec socket ${socket.id}`);
    });

    socket.on('disconnect', () => {
      const studentId = Object.keys(students).find((key) => students[key] === socket.id);
      if (studentId) {
        delete students[studentId];
        console.log(`❌ Étudiant ${studentId} déconnecté`);
      }
    });

    socket.on('sendAlertToAll', async ({ message }) => {
      try {
        console.log(`📢 Envoi d'une alerte à tous : ${message}`);

        // Récupérer tous les étudiants en base de données
        const [rows] = await pool.execute('SELECT id_etudiant FROM etudiants');
        const allStudents = rows.map(row => row.id_etudiant);

        // Enregistrer l'alerte pour tous les étudiants
        for (let id_etudiant of allStudents) {
          await saveAlert(id_etudiant, message);
        }

        // Envoyer l'alerte à tous les étudiants connectés
        sendDeadlineAlert(message);
      } catch (error) {
        console.error('❌ Erreur lors de l\'envoi des alertes :', error);
      }
    });
  });

  // Fonction pour envoyer une notification aux étudiants connectés
  const sendDeadlineAlert = (message) => {
    Object.values(students).forEach((socketId) => {
      io.to(socketId).emit('deadlineNotification', { message });
    });
  };

  // Fonction pour enregistrer une alerte en base de données
  async function saveAlert(id_etudiant, message) {
    try {
      await pool.execute(
        'INSERT INTO alertes (id_etudiant, notification, date_notification) VALUES (?, ?, NOW())',
        [id_etudiant, message]
      );
      console.log(`💾 Alerte enregistrée pour l'étudiant ${id_etudiant}`);
    } catch (error) {
      console.error(`❌ Erreur lors de l'enregistrement de l'alerte pour l'étudiant ${id_etudiant}:`, error);
    }
  }

  // Exemple de notification automatique toutes les 5 minutes
  setInterval(() => {
    sendDeadlineAlert('⚠️ Rappel : La date limite pour soumettre votre projet est demain !');
  }, 300000);

  // Route principale
  app.get('/', (req, res) => {
    res.render('index');
  });

  // Fonction pour récupérer les alertes d'un étudiant
  async function getNotifications(id_etudiant) {
    try {
      const [rows] = await pool.execute(
        'SELECT notification, date_notification FROM alertes WHERE id_etudiant = ? ORDER BY date_notification DESC',
        [id_etudiant]
      );
      return rows;
    } catch (error) {
      console.error('❌ Erreur lors de la récupération des alertes :', error);
      return [];
    }
  }

  // Lancer le serveur
  const port = process.env.PORT || 3020;
  server.listen(port, () => {
    console.log(`🚀 Serveur démarré sur le port ${port}`);
  });
});
